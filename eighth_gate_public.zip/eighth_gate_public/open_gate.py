#!/usr/bin/env python3
"""Open a gate:  python open_gate.py stage3.gate "the password"
Needs:  pip install cryptography
Format (nothing here is secret): magic EG8\x01, 16-byte salt, 12-byte nonce, AES-256-GCM of a zip.
Key = PBKDF2-HMAC-SHA256(password, salt, 300000). Passwords are uppercased; only A-Z and 0-9 count."""
import sys, re, io, hashlib, zipfile, os
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
path, pw = sys.argv[1], re.sub(r"[^A-Z0-9]", "", " ".join(sys.argv[2:]).upper())
d = open(path, "rb").read()
assert d[:4] == b"EG8\x01", "not a gate"
key = hashlib.pbkdf2_hmac("sha256", pw.encode(), d[4:20], 300000)
try: z = AESGCM(key).decrypt(d[20:32], d[32:], None)
except Exception: sys.exit("The gate stays shut.")
out = os.path.splitext(path)[0]
zipfile.ZipFile(io.BytesIO(z)).extractall(out)
print("The gate opens ->", out + "/")
