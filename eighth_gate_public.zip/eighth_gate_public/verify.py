#!/usr/bin/env python3
"""python verify.py manifest                      check every file is the creator's
python verify.py proof "Your Name" <signature-hex>   check a claim to have passed the Eighth Gate
Needs:  pip install cryptography"""
import sys, hashlib
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey as P
CREATOR = "0d8715bb5492e93e5f9ff085a2095028e89a9d9977c12a0d609a038c6bf8e246"
PRIZE = "b34165adcda1e4aa53c631a7f0f61b530f74acc06aae5f0ceefaaa0f737a4d25"
def ok(pub, sig, msg):
    try: P.from_public_bytes(bytes.fromhex(pub)).verify(bytes.fromhex(sig), msg); return True
    except Exception: return False
if sys.argv[1:2] == ["manifest"]:
    m = open("MANIFEST.txt", "rb").read()
    good = ok(CREATOR, open("MANIFEST.sig").read().strip(), m)
    for line in m.decode().splitlines():
        h, name = line.split("  ")
        good &= hashlib.sha256(open(name, "rb").read()).hexdigest() == h
    print("GENUINE" if good else "FORGERY")
elif sys.argv[1:2] == ["proof"]:
    print("PASSED" if ok(PRIZE, sys.argv[3], ("EIGHTH GATE PASSED BY " + sys.argv[2]).encode()) else "NOT VALID")
else: print(__doc__)
