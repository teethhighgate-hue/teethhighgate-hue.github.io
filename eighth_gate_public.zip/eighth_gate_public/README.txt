THE EIGHTH GATE

There are eight gates. Seven can be opened. The eighth must be made.

Begin with start.png. Throw nothing away.

  gate.html      open it in any browser. It opens a gate once you hold its password,
                 proves a file is ours, and proves a winner is real. Nothing to install.
  open_gate.py   the same gate-opener, for those who prefer Python
  verify.py      the same checks, for those who prefer Python

Anything not signed by this key is not from us:
  0d8715bb5492e93e5f9ff085a2095028e89a9d9977c12a0d609a038c6bf8e246

Whoever passes the last gate will hold a key. To prove it, sign the exact text
  EIGHTH GATE PASSED BY <your name>
and anyone can check the claim in gate.html.

No guessing is needed. No gate can be forced. Good luck.
